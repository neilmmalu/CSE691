1. This project needs to be run using Visual Studio, on a Windows machine. 
2. The default console window size needs to be set to at least 120x50
	2.a This can be done by Right-Clicking the console top bar
	2.b Select Defaults -> Layout -> Edit the window buffer size
	2.c You can also use the Properties option in the console bar
3. Currently, the simulation only supports single speed. The times will be detailed in the overview.
4. This simulation is infinite - it has been tested for 30 minutes without any deadlock or livelock. To end the simulation, the console must be closed.
